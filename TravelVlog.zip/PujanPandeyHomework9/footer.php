<!--This is the footer page of the website-->
<!--CS-385-->
<!--Pujan Pandey-->
<!--Spring 2024-->



<footer>
    <div class="footer-content">
        <p>&copy; 2024 Travel Hub. All rights reserved.</p>    
    </div>
</footer>
